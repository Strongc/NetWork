How To Share Files With Mongoose
===========================================

## 1. Download Mongoose executable from http://cesanta.com/mongoose.shtml and copy the executable inside the directory you want to share:

![screenshot](http://cesanta.com/images/tut_sharing/tut1.png)

## 2. Double-click mongoose executable. A browser will start automatically, an icon will appear on a system tray in the bottom right corner of the desktop:

![screenshot](http://cesanta.com/images/tut_sharing/tut2.png)

## 3. Click on the mongoose icon
![screenshot](http://cesanta.com/images/tut_sharing/tut3.png)


## 4. Click on "Go to my address" to launch a browser locally. Or, to access a folder from another machine, launch a browser and type in the URL:

![screenshot](http://cesanta.com/images/tut_sharing/tut4.png)
